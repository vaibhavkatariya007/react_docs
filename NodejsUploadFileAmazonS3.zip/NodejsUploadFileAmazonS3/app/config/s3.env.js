const env = {
	AWS_ACCESS_KEY: 'AKIAJMIPBAVVXRVB4AWA',
	AWS_SECRET_ACCESS_KEY: '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',
	REGION : 'us-east-2',
	Bucket: 'grokonez-s3-bucket'
};

module.exports = env;